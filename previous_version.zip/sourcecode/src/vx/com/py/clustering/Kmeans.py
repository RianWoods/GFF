#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: Liz M. Huancapaza Hilasaca
# Copyright (c) 2020
# E-mail: lizhh@usp.br


import math
import random

import queue as Q

from vx.com.py.proximity.Proximity import *

class BKmeans:
    def __init__(self):
        pass

