# install python
sudo apt-get install build-essential
sudo apt-get install cmake
sudo apt-get install gcc
sudo apt-get install python3
sudo apt-get install python3-venv
sudo apt-get install python3-pip
sudo apt-get install python3-scipy libsuitesparse-dev


# pythnon virtual enviroment
pip3 install virtualenv

rm -r ./python38
mkdir ./python38
python3 -m venv ./python38
source ./python38/bin/activate

# install packages
# pip3 install -r requirementspgff.txt
pip3 install wheel
pip3 install numpy
pip3 install scikit-sparse
pip3 install tornado
pip3 install ujson
pip3 install matplotlib
pip3 install sklearn
pip3 install pandas
pip3 install cython
pip3 install pymongo
pip3 install bcrypt
pip3 install scipy
pip3 install umap-learn
pip3 install MulticoreTSNE

#compile task 1
cd ./sourcecode/src/vx/com/px/dataset/
sh Makefile.sh

cd ../../../../../../

#compile task 2
cd ./sourcecode/src/vx/pgff/graphtree/
sh Makefile.sh
